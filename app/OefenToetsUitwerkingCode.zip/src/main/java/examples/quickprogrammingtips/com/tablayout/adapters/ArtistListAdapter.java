package examples.quickprogrammingtips.com.tablayout.adapters;

/**
 * Created by anton on 20-1-16.
 */

        import android.content.Context;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.BaseAdapter;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.util.ArrayList;

        import examples.quickprogrammingtips.com.tablayout.R;
        import examples.quickprogrammingtips.com.tablayout.model.Artist;

public class ArtistListAdapter extends BaseAdapter {

    private static ArrayList<Artist> artistList;
    private LayoutInflater mInflater;

    public ArtistListAdapter(Context artistFragmentContext, ArrayList<Artist> artists) {

        artistList = artists;

        mInflater = LayoutInflater.from(artistFragmentContext);
    }

    @Override
    public int getCount() {
        return artistList.size();
    }

    @Override
    public Artist getItem(int arg0) {
        return artistList.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_performer, null);
            holder = new ViewHolder();
            holder.performer = (TextView) convertView.findViewById(R.id.textViewPerformer);
            holder.country = (TextView) convertView.findViewById(R.id.textViewPerformerCountry);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.performer.setText(artistList.get(position).getName());
        holder.country.setText(artistList.get(position).getCountry());

        final String artistName = artistList.get(position).getName();
        Log.v("test", artistName);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t = Toast.makeText(v.getContext(), artistName, Toast.LENGTH_SHORT);
                t.show();
            }
        });

        return convertView;
    }

    static class ViewHolder{
        TextView performer, country;
    }


}