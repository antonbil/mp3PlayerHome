package examples.quickprogrammingtips.com.tablayout;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;//must be changed; Android Studio makes it Fragment!?
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

//test line

public class DataFragment extends Fragment implements OnTaskCompleted {
    public static final String NUMBEROFMOVES = "numberofmoves";
    private final OnTaskCompleted onTaskCompleted = this;//enables call-back methods
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // Make sure that container activity implement the callback interface
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            // Inflate the layout for this fragment
            View view =  inflater.inflate(R.layout.fragment_data, container, false);

            Button dataButton = (Button) view.findViewById(R.id.listMovesButton);
            dataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //send call to get number of players
                    String urlString = MainActivity.CARD_API + "games/ip/numplayers";
                    new CallAPI(onTaskCompleted, NUMBEROFMOVES).execute(urlString, getString(R.string.GET));
                }
            });
            return view;
        }
    private void numberOfMoves(String result) {
        //change result, so it can be processed more easily
        //the result will be an object within an object
        result=result.replace("[{", "{");
        result=result.replace("}]", "}");
        result=result.replace("},{", ",");
        Log.v("score", result);

        //now parse result
        try {
            //first get outer object
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.has("result")) {
                //get result-parameter
                JSONObject object = jsonObject.getJSONObject("result");
                //setup javascript object to process data for webview
                //getactivity() to get Context of Activity
                final JavaScriptInterface myJavaScriptInterface
                        //now it is easy to extract 5 numbers from result
                        //large object with 5 properties: 2,3,4,5,6; object can be {"4",56}
                        = new JavaScriptInterface( getActivity(),object.getInt("2"),object.getInt("3"),object.getInt("4"),object.getInt("5"),object.getInt("6"));
                //create Webview
                final WebView webView;
                webView = (WebView)getActivity().findViewById(R.id.web);

                //load webview on main thread
                webView.post(new Runnable() {
                    @Override
                    public void run() {
                        //interface to exchange data
                        webView.addJavascriptInterface(myJavaScriptInterface, "Android");

                        webView.getSettings().setJavaScriptEnabled(true);
                        webView.loadUrl("file:///android_asset/chart.html");
                    }
                });
            } else if (jsonObject.has("error")) {
                Log.v("JSON+", jsonObject.getString("error"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onTaskCompleted(String result, String call) {
        if (call.equals(NUMBEROFMOVES)) numberOfMoves(result);
    }
    public class JavaScriptInterface {
        Context mContext;
        ArrayList<String> list;

        private int num1=3,num2=5,num3=2,num4=8,num5=2;
        JavaScriptInterface(Context c, ArrayList<String> list) {
            this.list=list;
            mContext = c;
        }
        JavaScriptInterface(Context c, int num1, int num2, int num3,int num4,int num5) {
            this.num1=num1;
            this.num2=num2;
            this.num3=num3;
            this.num4=num4;
            this.num5=num5;
            mContext = c;
        }


         @JavascriptInterface
         public int getNum1() {
    return num1;
    }

        @JavascriptInterface
        public int getNum2() {
            return num2;
        }

        @JavascriptInterface
        public int getNum3() {
            return num3;
        }

        @JavascriptInterface
        public int getNum4() {
            return num4;
        }

        @JavascriptInterface
        public int getNum5() {
            return num5;
        }

    }
}
