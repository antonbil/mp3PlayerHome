package examples.quickprogrammingtips.com.tablayout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

import examples.quickprogrammingtips.com.tablayout.adapters.ArtistListAdapter;
import examples.quickprogrammingtips.com.tablayout.model.Artist;


public class ArtistsFragment extends Fragment {
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_artists, container, false);


            final ListView artistListView = (android.widget.ListView) view.findViewById(R.id.listViewArtists);

            //code for simple list-adapter
            final ArrayList<String> itemList = new ArrayList<>();

            //Declare adapter
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                    android.R.layout.simple_list_item_1, itemList);


            //fill itemlist with data
            itemList.add("Bad Company");
            itemList.add("Band");
            itemList.add("Barclay James Harvest");
            itemList.add("Peter Bardens");
            itemList.add("Be-Bop Deluxe");
            itemList.add("Beach Boys");
            itemList.add("Beatles");
            itemList.add("Beethoven");
            itemList.add("Bill Bruford");
            itemList.add("Bintangs");
            itemList.add("Bjork");
            itemList.add("Black Keys");
            itemList.add("Black Uhuru");
            itemList.add("Blind Faith");
            itemList.add("Blondie");
            itemList.add("Blodd, Sweat&Tears");
            itemList.add("Bookter T and the MG's");
            itemList.add("Bootsy's Rubber Band");
            itemList.add("Brainbox");
            itemList.add("Bread");
            itemList.add("Buena Vista Social Club");
            itemList.add("Byrds");


            //display simple list adapter
            //commented out because this example displays a more complicated adapter
            //artistListView.setAdapter(adapter);

            //now code for special adapter
            ArrayList<Artist> artists = new ArrayList<>(Arrays.asList(
                    new Artist("Peter Bardens", "England"),
                    new Artist("Bill Bruford", "England"),
                    new Artist("David Bowie", "England"),
                    new Artist("Bjork", "Iceland"),
                    new Artist("Abba", "Sweden"),
                    new Artist("Marco Borsato", "Netherlands"),
                    new Artist("K3", "Belgium"),
                    new Artist("Ange", "France"),
                    new Artist("Michael Jackson", "USA"),
                    new Artist("Eagles", "USA"),
                    new Artist("Bruce Springsteen", "USA")
                    //becomes more complicated if you also want to use bands.
                    // In that case a country-field can be introduced for a Performer,
                    //or you can check in the ListAdapter if it is an Artist yes/no ; if (obj instanceof Artist)
                )
            );
            artistListView.setAdapter(new ArtistListAdapter(getActivity(), artists));

            artistListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    int itempos = position;
                    String getId;

                    getId = (String) artistListView.getItemAtPosition(position);
                    //alert can also be done with a Toast
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            getContext());
                    // set dialog message
                    alertDialogBuilder
                            .setMessage("You clicked on " + getId)
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // if this button is clicked, close
                                    // current dialog
                                    dialog.cancel();
                                }
                            });
                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    // show it
                    alertDialog.show();
                }
            });


            // Inflate the layout for this fragment
            return view;
        }
    }
