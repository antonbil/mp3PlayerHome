package examples.quickprogrammingtips.com.tablayout;

/**
 * Created by anton on 28-1-16.
 */
public class Composer {
    public final String TAG = Composer.class.getSimpleName();

    public String name;
    public String year;

    public Composer(String name, String year) {
        this.name = name;
        this.year = year;
    }
}
