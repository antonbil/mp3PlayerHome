package examples.quickprogrammingtips.com.tablayout;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.util.Pair;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import examples.quickprogrammingtips.com.tablayout.adapters.AmazingAdapter;
import examples.quickprogrammingtips.com.tablayout.adapters.AmazingListView;
import examples.quickprogrammingtips.com.tablayout.adapters.FavoriteListAdapter;
import examples.quickprogrammingtips.com.tablayout.model.Favorite;
import examples.quickprogrammingtips.com.tablayout.model.FavoriteRecord;
import examples.quickprogrammingtips.com.tablayout.model.Logic;
import examples.quickprogrammingtips.com.tablayout.model.Server;


public class SelectFragment extends Fragment implements FavoritesInterface{
    static final int STATIC_RESULT=2; //positive > 0 integer.
    private Logic logic;
    ArrayList<Favorite> favorites;
    ListView favoriteListView;
    FavoriteListAdapter favoriteListAdapter;
    AmazingListView lsComposer;
    PaginationComposerAdapter adapter;
    Data data=new Data();
    private ArrayList<Server>servers=Server.servers;//Server.servers.get(Server.getServer(getActivity())).url;
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            servers.toArray();
            favorites = new ArrayList<>();


            // Inflate the layout for this fragment
            logic =((MainActivity)getActivity()).getLogic();
            View view = inflater.inflate(R.layout.fragment_select, container, false);
            final SharedPreferences app_preferences =
                    PreferenceManager.getDefaultSharedPreferences(getActivity());

            // Get the value for the run counter
            int server = Server.getServer(getActivity());
            RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.select_radioGroup);
            radioGroup.check(servers.get(server).code);
            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {


                @Override

                public void onCheckedChanged(RadioGroup group, int checkedId) {

                    // find which radio button is selected
                    for (int i = 0; i < servers.size(); i++) {
                        if (checkedId == servers.get(i).code) {
                            setAddress(servers.get(i).url);
                            //Toast.makeText(getActivity(), "choice: "+servers.get(i).description,

                            //Toast.LENGTH_SHORT).show();
                            Server.setServer(i, getActivity());
                        }
                    }

                }

            });

            favoriteListView = (android.widget.ListView) view.findViewById(R.id.selectlistView);
            favoriteListView.setLongClickable(true);
            favoriteListAdapter = new FavoriteListAdapter(getActivity(), this, favorites);
            favoriteListView.setAdapter(favoriteListAdapter);
            getFavorites();
            //lsComposer = (AmazingListView) getActivity().findViewById(R.id.lsComposer);
            //lsComposer.setLoadingView(inflater.inflate(R.layout.loading_view, null));
            //adapter = new PaginationComposerAdapter();
            //lsComposer.setAdapter(adapter);

            //adapter.notifyMayHaveMorePages();


            return view;
        }

    @NonNull
    public void getFavorites() {
        List<FavoriteRecord> favoritesDisk = FavoriteRecord.listAll(FavoriteRecord.class);
        favorites.add(new Favorite("smb://192.168.2.8/FamilyLibrary/years/", "years"));
        favorites.add(new Favorite("smb://192.168.2.8/FamilyLibrary/Soul/", "Soul"));
        favorites.add(new Favorite("smb://192.168.2.8/FamilyLibrary/favorites/", "favorites"));
            /*List<FavoriteRecord> books = new ArrayList<>();
            books.add(new FavoriteRecord("isbn123", "Title here", "2nd edition"));
            books.add(new FavoriteRecord("isbn456", "Title here 2", "3nd edition"));
            books.add(new FavoriteRecord("isbn789", "Title here 3", "4nd edition"));
            SugarRecord.saveInTx(books);*/
        for (FavoriteRecord fav:favoritesDisk){
            Favorite favnew=new Favorite(fav.url,fav.description);
            favnew.setRecord(fav);
            favorites.add(favnew);
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                favoriteListAdapter.notifyDataSetChanged();

            }
        });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        if (v.getId()==R.id.selectlistView) {
        }
    }
    public void setAddress(String address) {
        logic.openServer(address);
        logic.getMpc().setMPCListener((MainActivity) getActivity());
    }

    @Override
    public void favoritesCall(Favorite favorite, String id) {
        if (id=="edit"){
            if (favorite.getRecord()!=null) {
                Intent intent = new Intent(getActivity(), EditFavoriteActivity.class);
                intent.putExtra("id", (int)(favorite.getRecord().getId()+0));
                intent.putExtra("url", favorite.getRecord().url);
                intent.putExtra("description", favorite.getDescription());
                startActivityForResult(intent, STATIC_RESULT);
            }


        } else
        if (id=="delete"){
            if (favorite.getRecord()!=null) {

                FavoriteRecord book = FavoriteRecord.findById(FavoriteRecord.class, favorite.getRecord().getId());
                book.delete();
                favorites.clear();
                getFavorites();
            }

        } else {
            logic.getHistory().add(favorite.getUri());
            ((MainActivity) getActivity()).selectTab(1);
        }

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == STATIC_RESULT) //check if the request code is the one you've sent
        {
            if (resultCode == Activity.RESULT_OK)
            {
                // this is successful mission, do with it.
                Toast.makeText(getContext(), "succesfully returned!", Toast.LENGTH_SHORT).show();
                favorites.clear();
                getFavorites();


                } else {
                // the result code is different from the one you've finished with, do something else.
            }
        }


        super.onActivityResult(requestCode, resultCode, data);

    }
    class Data {
        public  final String TAG = Data.class.getSimpleName();

        public  Pair<Boolean, List<Composer>> getRows(int page) {
            List<Composer> flattenedData = getFlattenedData();
            if (page == 1) {
                return new Pair<Boolean, List<Composer>>(true, flattenedData.subList(0, 5));
            } else {
                SystemClock.sleep(2000); // simulate loading
                return new Pair<Boolean, List<Composer>>(page * 5 < flattenedData.size(), flattenedData.subList((page - 1) * 5, Math.min(page * 5, flattenedData.size())));
            }
        }
        public  Pair<String, List<Composer>> getOneSection(int index) {
            String[] titles = {"Renaissance", "Baroque", "Classical", "Romantic"};
            Composer[][] composerss = {
                    {
                            new Composer("Thomas Tallis", "1510-1585"),
                            new Composer("Josquin Des Prez", "1440-1521"),
                            new Composer("Pierre de La Rue", "1460-1518"),
                    },
                    {
                            new Composer("Johann Sebastian Bach", "1685-1750"),
                            new Composer("George Frideric Handel", "1685-1759"),
                            new Composer("Antonio Vivaldi", "1678-1741"),
                            new Composer("George Philipp Telemann", "1681-1767"),
                    },
                    {
                            new Composer("Franz Joseph Haydn", "1732-1809"),
                            new Composer("Wolfgang Amadeus Mozart", "1756-1791"),
                            new Composer("Barbara of Portugal", "1711Ð1758"),
                            new Composer("Frederick the Great", "1712Ð1786"),
                            new Composer("John Stanley", "1712Ð1786"),
                            new Composer("Luise Adelgunda Gottsched", "1713Ð1762"),
                            new Composer("Johann Ludwig Krebs", "1713Ð1780"),
                            new Composer("Carl Philipp Emanuel Bach", "1714Ð1788"),
                            new Composer("Christoph Willibald Gluck", "1714Ð1787"),
                            new Composer("Gottfried August Homilius", "1714Ð1785"),
                    },
                    {
                            new Composer("Ludwig van Beethoven", "1770-1827"),
                            new Composer("Fernando Sor", "1778-1839"),
                            new Composer("Johann Strauss I", "1804-1849"),
                    },
            };
            return new Pair<String, List<Composer>>(titles[index], Arrays.asList(composerss[index]));
        }
        public  List<Pair<String, List<Composer>>> getAllData() {
            List<Pair<String, List<Composer>>> res = new ArrayList<Pair<String, List<Composer>>>();

            for (int i = 0; i < 4; i++) {
                res.add(getOneSection(i));
            }

            return res;
        }
        public List<Composer> getFlattenedData() {
            List<Composer> res = new ArrayList<Composer>();

            for (int i = 0; i < 4; i++) {
                res.addAll(getOneSection(i).second);
            }

            return res;
        }


    }


    class PaginationComposerAdapter extends AmazingAdapter {
        List<Composer> list = data.getRows(1).second;
        private AsyncTask<Integer, Void, Pair<Boolean, List<Composer>>> backgroundTask;

        public void reset() {
            if (backgroundTask != null) backgroundTask.cancel(false);

            list = data.getRows(1).second;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Composer getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        protected void onNextPageRequested(int page) {
            Log.d(TAG, "Got onNextPageRequested page=" + page);

            if (backgroundTask != null) {
                backgroundTask.cancel(false);
            }

            backgroundTask = new AsyncTask<Integer, Void, Pair<Boolean, List<Composer>>>() {
                @Override
                protected Pair<Boolean, List<Composer>> doInBackground(Integer... params) {
                    int page = params[0];

                    return data.getRows(page);
                }

                @Override
                protected void onPostExecute(Pair<Boolean, List<Composer>> result) {
                    if (isCancelled()) return;

                    list.addAll(result.second);
                    nextPage();
                    notifyDataSetChanged();

                    if (result.first) {
                        // still have more pages
                        notifyMayHaveMorePages();
                    } else {
                        notifyNoMorePages();
                    }
                };
            }.execute(page);
        }

        @Override
        protected void bindSectionHeader(View view, int position, boolean displaySectionHeader) {
        }

        @Override
        public View getAmazingView(int position, View convertView, ViewGroup parent) {
            View res = convertView;
            if (res == null) res = getActivity().getLayoutInflater().inflate(R.layout.item_composer, null);

            // we don't have headers, so hide it
            res.findViewById(R.id.header).setVisibility(View.GONE);

            TextView lName = (TextView) res.findViewById(R.id.lName);
            TextView lYear = (TextView) res.findViewById(R.id.lYear);

            Composer composer = getItem(position);
            lName.setText(composer.name);
            lYear.setText(composer.year);

            return res;
        }

        @Override
        public void configurePinnedHeader(View header, int position, int alpha) {
        }

        @Override
        public int getPositionForSection(int section) {
            return 0;
        }

        @Override
        public int getSectionForPosition(int position) {
            return 0;
        }

        @Override
        public Object[] getSections() {
            return null;
        }

    }

}
