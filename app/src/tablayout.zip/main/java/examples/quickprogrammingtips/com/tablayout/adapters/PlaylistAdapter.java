package examples.quickprogrammingtips.com.tablayout.adapters;

/**
 * Created by anton on 20-1-16.
 */

import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import examples.quickprogrammingtips.com.tablayout.MainActivity;
import examples.quickprogrammingtips.com.tablayout.MpdInterface;
import examples.quickprogrammingtips.com.tablayout.PlayFragment;
import examples.quickprogrammingtips.com.tablayout.R;
import examples.quickprogrammingtips.com.tablayout.model.File;
import examples.quickprogrammingtips.com.tablayout.model.Mp3File;

public class PlaylistAdapter extends BaseAdapter {

    private static ArrayList<Mp3File> fileArrayList;
    private final PlayFragment selectFragmentContext;
    private LayoutInflater mInflater;
    private MpdInterface caller;
    private int currentSongInPlaylist=-1;

    public PlaylistAdapter(PlayFragment selectFragmentContext, MpdInterface caller, ArrayList<Mp3File> files) {

        fileArrayList = files;
        this.caller=caller;

        this.selectFragmentContext = selectFragmentContext;
        mInflater = LayoutInflater.from(this.selectFragmentContext.getContext());
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }
    @Override
    public int getItemViewType(int position) {
        Mp3File mp3File = fileArrayList.get(position);

        return (mp3File.isStartAlbum()) ? 0 : 1;
    }

    @Override
    public int getCount() {
        return fileArrayList.size();
    }

    @Override
    public File getItem(int arg0) {
        return fileArrayList.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    public void setCurrentSong(int currentSong){
        this.currentSongInPlaylist=currentSong;
    }

    public void onGroupItemClick (MenuItem item) {
        if (item.isChecked()) {
            item.setChecked(false);
        } else {
            item.setChecked(true);
        }
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        try{
            ViewHolder holder;
            final Mp3File mp3File = fileArrayList.get(position);
            int type = getItemViewType(position);
            if(convertView == null){
                if (mp3File.isStartAlbum())
                    convertView = mInflater.inflate(R.layout.itemalbum_playlist, null);
                    else
                convertView = mInflater.inflate(R.layout.item_playlist, null);
                holder = new ViewHolder();
                holder.performer = (TextView) convertView.findViewById(R.id.textViewPerformer);
                holder.time = (TextView) convertView.findViewById(R.id.textViewPerformerCountry);

                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            if (position==currentSongInPlaylist)convertView.setBackgroundColor(Color.rgb(40,40,40));//
            else
            if ( (position & 1) == 0 ) { convertView.setBackgroundColor(Color.rgb(57, 57, 57)); } else convertView.setBackgroundColor(Color.rgb(64, 64, 64));

            if (!mp3File.isStartAlbum()) {
                String albumId = String.format("%s-%s", mp3File.getTracknr(), mp3File.getTitle());

                holder.performer.setText(albumId);
            }
            else {
                ImageView image=(ImageView) (convertView.findViewById(R.id.thumbnail_playlist));
                String niceAlbum = mp3File.niceAlbum();
                if (MainActivity.albumPictures.containsKey(niceAlbum)&&MainActivity.albumPictures.get(niceAlbum)!=null)
                    image.setImageBitmap(MainActivity.albumPictures.get(niceAlbum));
                else image.setImageBitmap(BitmapFactory.decodeResource(convertView.getResources(), R.drawable.pause));
                holder.performer.setText(String.format("%s-%s\n%s-%s", mp3File.getArtist(), mp3File.getAlbum(), mp3File.getTracknr(), mp3File.getTitle()));
            }
            holder.time.setText(mp3File.getTimeNice());
            final int pos2=position;
            convertView.setOnLongClickListener(new AdapterView.OnLongClickListener() {

                @Override
                public boolean onLongClick(final View v) {
                            Log.v("test", fileArrayList.get(pos2).getFname());
                            //Toast.makeText(v.getContext(), "click:" + (String) fileArrayList.get(pos2).getName(), Toast.LENGTH_LONG).show();
                            PopupMenu menu = new PopupMenu(v.getContext(), v);

                            menu.getMenu().add(R.string.playlist_removeall);
                            menu.getMenu().add(R.string.playlist_removeabum);
                    menu.getMenu().add(R.string.playlist_removesong);
                            menu.getMenu().add(R.string.playlist_removetop);
                            menu.getMenu().add(R.string.playlist_removebottom);
                            menu.getMenu().add("move->");//submenu
                            menu.show();
                            final View v1 = v;
                            menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                                @Override
                                public boolean onMenuItemClick(MenuItem item) {
                                    if (item.getTitle().toString().equals("move->")) {
                                        //submenu
                                        PopupMenu menu = new PopupMenu(v.getContext(), v);

                                        menu.getMenu().add(R.string.playlist_movebottom);
                                        menu.getMenu().add(R.string.playlist_down);
                                        menu.show();
                                        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                                            @Override
                                            public boolean onMenuItemClick(MenuItem item) {
                                                caller.newMpdCall(mp3File, position, item.getTitle().toString());
                                                Toast.makeText(v1.getContext(), "click:" + fileArrayList.get(pos2).getFname() + ":" + item.getTitle(), Toast.LENGTH_LONG).show();
                                                return true;


                                            }

                                            ;
                                        });
                                    } else                                    //Toast.makeText(v1.getContext(), "click:" + fileArrayList.get(pos2).getFname() + ":" + item.getTitle(), Toast.LENGTH_LONG).show();
                                    caller.newMpdCall(mp3File, position, item.getTitle().toString());
                                    return true;
                                }

                            });
                    return true;
                }
                    });
                final String fname = mp3File.getFname();
                final String path= mp3File.getFile();
                Log.v("test", fname);
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                            //Mp3File mp=(Mp3File) mp3File;
                            //mp.getMpcSong()
                            //Toast t = Toast.makeText(v.getContext(), "play:"+mp.getTitle(), Toast.LENGTH_SHORT);
                        caller.newMpdCall(mp3File, position, selectFragmentContext.getString(R.string.command_play));
                            //t.show();
                    }
                });
            } catch (Exception e) {
                //successful = false;
                e.printStackTrace();
            }

        return convertView;
    }

    static class ViewHolder{
        TextView performer, time;
    }


}