package examples.quickprogrammingtips.com.tablayout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import examples.quickprogrammingtips.com.tablayout.model.FavoriteRecord;

/**
 * A login screen that offers login via email/password.
 */
public class EditFavoriteActivity extends AppCompatActivity{

    // UI references.
    private EditText url;
    private EditText description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_favorite);
        // Set up the login form.
        url = (EditText) findViewById(R.id.url);

        description = (EditText) findViewById(R.id.description);


        Button save = (Button) findViewById(R.id.save_button);

        Bundle extras = getIntent().getExtras();


        String   urlString= extras.getString("url");
        String    descriptionString= extras.getString("description");
        final int    idString= extras.getInt("id");

        url.setText(urlString);
        description.setText(descriptionString);

        save.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                try {
                    FavoriteRecord book = FavoriteRecord.findById(FavoriteRecord.class, idString);
                    book.url = url.getText().toString();
                    book.description = description.getText().toString();
                    book.save();
                    Intent i = getIntent(); //get the intent that has been called, i.e you did called with startActivityForResult();
                    //i.putExtras(b);//put some data, in a bundle
                    setResult(Activity.RESULT_OK, i);  //now you can use Activity.RESULT_OK, its irrelevant whats the resultCode
                    finish(); //finish the startNewOne activity
                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), "Error!", Toast.LENGTH_SHORT).show();

                }

            }

        });


    }

}

