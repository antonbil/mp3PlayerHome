package examples.quickprogrammingtips.com.tablayout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import examples.quickprogrammingtips.com.tablayout.adapters.ArtistListAdapter;
import examples.quickprogrammingtips.com.tablayout.adapters.FileListAdapter;
import examples.quickprogrammingtips.com.tablayout.model.Artist;
import examples.quickprogrammingtips.com.tablayout.model.FavoriteRecord;
import examples.quickprogrammingtips.com.tablayout.model.File;
import examples.quickprogrammingtips.com.tablayout.model.Logic;
import examples.quickprogrammingtips.com.tablayout.model.Mp3File;
import examples.quickprogrammingtips.com.tablayout.tools.NetworkShare;
import mpc.DatabaseCommand;
import mpc.MPCDatabaseListener;
import mpc.MPCSong;


public class DBFragment extends Fragment implements MPCDatabaseListener  , SambaInterface{
    ArrayList<File> files = new ArrayList<>();
    private FileListAdapter fileListAdapter;
    NetworkShare networkShare;
    Logic logic;
    private ArrayList<File> currentFiles;//chdb
    private boolean playit=false;//chdb
    private String currentId;//chdb

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        logic =((MainActivity)getActivity()).getLogic();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        final ListView fileListView = (android.widget.ListView) view.findViewById(R.id.listViewFiles);
        fileListAdapter = new FileListAdapter(getActivity(),this, files);
        fileListView.setAdapter(fileListAdapter);
        registerForContextMenu(fileListView);
        
        displayContents(logic.getHistoryMpd().get(logic.getHistoryMpd().size() - 1));//chdb
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.v("DBFragment", "DB fragment onstart");//chdb
    }


    @Override
    public void sambaCallCompleted(ArrayList<File> files1a, String id) {
        if (!isAdded()){
            MainActivity.panicMessage("ListFragment is detached from Activity");
            return;
        }

        if (id==getString(R.string.select_filelist)) {
            Collections.sort(files1a, new CustomComparator());
            for (int i = 0; i < files1a.size(); i++) {
                //Log.v("samba", "nu2:" + files1a.get(i).toString());
                //playlistFiles.add(files1.get(i));
            }
            files.clear();
            final ArrayList<File> files1 = files1a;
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    files.addAll(files1);
                    fileListAdapter.notifyDataSetChanged();

                }
            });
        } else{

        }
    }

    @Override
    public void newSambaCall(String path, String id) {
        if (!isAdded()){
            MainActivity.panicMessage("DBFragment is detached from Activity");//chdb
            return;
        }
        if (id.equals(getString(R.string.addsong_filelist))){
            String message = "add \"" + path + "\"";
            logic.getMpc().sendSingleMessage(message);
        }else {//todo not necessary for db!? otherwise other category!
            if (id==getString(R.string.select_filelist))
                //networkShare.getContent(this, path, id);
                displayContents(path);//chdb
            else  if (id==getString(R.string.addtofavorites_filelist)){
                String[] paths=path.split("/");
                FavoriteRecord fv=new FavoriteRecord(path, paths[paths.length-1], "2nd edition");
                fv.save();
            }else {//chdb entire one
                playit=true;
                currentId=id;
                //if path is filename
                if (path.endsWith(".mp3")){
                    String[] pathLines=path.split("/");
                    String f=pathLines[pathLines.length-1];
                    path=path.substring(0,path.length()-f.length()-1);
                    Log.v("samba","play "+path);
                }
                displayContents(path);
            }
            if (id == getString(R.string.select_filelist)) {

                logic.getHistoryMpd().add(path);//chdb
            }
        }
    }


    public void displayContents(String path) {
        new DatabaseCommand(logic.getMpc(),"lsinfo \""+path+"\"",this).run();
    }

    public void back(){
        String newPath="";
        for (int j=1;j<=2;j++) {
            int last = logic.getHistoryMpd().size() - 1;//chdb
            newPath= logic.getHistoryMpd().get(last);//chdb
            if (last>=1) logic.getHistoryMpd().remove(last);//chdb
        }
        logic.getHistoryMpd().add(newPath);//chdb
        displayContents(newPath);//chdb
    }
    public class CustomComparator implements Comparator<File> {
        @Override
        public int compare(File o1, File o2) {
            if (o1 instanceof Mp3File)
                if (o2 instanceof Mp3File){
                    Integer m1=((Mp3File)o1).getTracknr();
                    Integer m2=((Mp3File)o2).getTracknr();
                    return (m1.compareTo(m2));
                } else return 1;
            else if(o2 instanceof Mp3File) return 0;
            else
                return o1.getFname().compareTo(o2.getFname());
        }
    }


    //chdb from now on
    @Override
    public void databaseUpdated() {

    }

    @Override
    public void databaseUpdateProgressChanged(int progress) {

    }

    @Override
    public void connectionFailed(String message) {

    }

    @Override
    public void databaseCallCompleted(final ArrayList<File> files1a) {
        if (playit){
            logic.sambaCallCompleted(files1a, currentId);//chdb
            playit=false;
        } else {

            currentFiles = files1a;
//        for (File file:files1a)
//        if (file instanceof Mp3File) {
//            Mp3File f=(Mp3File)file;
//            Log.v("samba", f.getArtist() + "-" + f.getTitle());
//        } else
//            Log.v("samba", file.getPath() + "-" + file.getFname());
            Collections.sort(files1a, new CustomComparator());
            for (int i = 0; i < files.size(); i++) {
                //Log.v("samba", "nu2:" + files1a.get(i).toString());
                //playlistFiles.add(files1.get(i));
            }
            files.clear();
            final ArrayList<File> files1 = files1a;
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    files.addAll(files1);
                    fileListAdapter.notifyDataSetChanged();

                }
            });
        }


    }
}
