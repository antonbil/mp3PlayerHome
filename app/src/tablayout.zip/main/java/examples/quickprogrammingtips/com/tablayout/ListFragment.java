package examples.quickprogrammingtips.com.tablayout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import examples.quickprogrammingtips.com.tablayout.adapters.FileListAdapter;
import examples.quickprogrammingtips.com.tablayout.model.FavoriteRecord;
import examples.quickprogrammingtips.com.tablayout.model.File;
import examples.quickprogrammingtips.com.tablayout.model.Logic;
import examples.quickprogrammingtips.com.tablayout.model.Mp3File;
import examples.quickprogrammingtips.com.tablayout.tools.NetworkShare;
import mpc.MPC;
import mpc.MPCSong;


public class ListFragment extends Fragment implements SambaInterface{
    ArrayList<File> files = new ArrayList<>();
    private FileListAdapter fileListAdapter;
    NetworkShare networkShare;
    Logic logic;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        logic =((MainActivity)getActivity()).getLogic();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        final ListView fileListView = (android.widget.ListView) view.findViewById(R.id.listViewFiles);
        fileListAdapter = new FileListAdapter(getActivity(),this, files);
        fileListView.setAdapter(fileListAdapter);
        registerForContextMenu(fileListView);

        networkShare=new NetworkShare();
        //networkShare.doTest();

        networkShare.getContent(this, logic.getHistory().get(logic.getHistory().size() - 1),getString(R.string.select_filelist));
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.v("ListFragment", "onstart");
    }


    @Override
    public void sambaCallCompleted(ArrayList<File> files1a, String id) {
        if (!isAdded()){
            MainActivity.panicMessage("ListFragment is detached from Activity");
           return;
        }

        if (id==getString(R.string.select_filelist)) {
            Collections.sort(files1a, new CustomComparator());
            for (int i = 0; i < files1a.size(); i++) {
                //Log.v("samba", "nu2:" + files1a.get(i).toString());
                //playlistFiles.add(files1.get(i));
            }
            files.clear();
            final ArrayList<File> files1 = files1a;
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    files.addAll(files1);
                    fileListAdapter.notifyDataSetChanged();

                }
            });
        } else{

        }
    }

    @Override
    public void newSambaCall(String path, String id) {
        if (!isAdded()){
            MainActivity.panicMessage("ListFragment is detached from Activity");
            return;
        }
        if (id.equals(getString(R.string.addsong_filelist))){
            String message = "add \"" + path + "\"";
            logic.getMpc().sendSingleMessage(message);
            Log.v("samba",message);
        }else {
            if (id==getString(R.string.select_filelist))
            networkShare.getContent(this, path, id);
            else  if (id==getString(R.string.addtofavorites_filelist)){
                        String[] paths=path.split("/");
                        FavoriteRecord fv=new FavoriteRecord(path, paths[paths.length-1], "2nd edition");
                        fv.save();
                    }else
                        networkShare.getContent(logic, path, id);
            if (id == getString(R.string.select_filelist)) {

                logic.getHistory().add(path);
            }
        }
    }

    public void back(){
        String newPath="";
        for (int j=1;j<=2;j++) {
            int last = logic.getHistory().size() - 1;
            newPath= logic.getHistory().get(last);
            if (last>=1) logic.getHistory().remove(last);
        }
        logic.getHistory().add(newPath);
        networkShare.getContent(this,newPath,getString(R.string.select_filelist));
    }
    public class CustomComparator implements Comparator<File> {
        @Override
        public int compare(File o1, File o2) {
            if (o1 instanceof Mp3File)
                if (o2 instanceof Mp3File){
                    Integer m1=((Mp3File)o1).getTracknr();
                    Integer m2=((Mp3File)o2).getTracknr();
                    return (m1.compareTo(m2));
                } else return 1;
            else if(o2 instanceof Mp3File) return 0;
            else
            return o1.getFname().compareTo(o2.getFname());
        }
    }
}
