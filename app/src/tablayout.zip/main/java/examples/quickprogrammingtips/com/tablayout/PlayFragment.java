package examples.quickprogrammingtips.com.tablayout;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;

import examples.quickprogrammingtips.com.tablayout.adapters.PlaylistAdapter;
import examples.quickprogrammingtips.com.tablayout.model.Logic;
import examples.quickprogrammingtips.com.tablayout.model.Mp3File;

//test line

public class PlayFragment extends Fragment implements MpdInterface {

    private PlaylistAdapter fileListAdapter;
    private Logic logic;
    PlayFragment playFragment;
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // Make sure that container activity implement the callback interface
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            playFragment=this;
            // Inflate the layout for this fragment
            logic =((MainActivity)getActivity()).getLogic();
            //PlaylistThread playlistThread=new PlaylistThread(this, logic.getMpc());
            //playlistThread.run();
            View view = inflater.inflate(R.layout.fragment_list, container, false);
            final ListView fileListView = (android.widget.ListView) view.findViewById(R.id.listViewFiles);
            fileListAdapter = new PlaylistAdapter(this,this, logic.getPlaylistFiles());
            fileListView.setAdapter(fileListAdapter);
            registerForContextMenu(fileListView);

            ((MainActivity)getActivity()).playlistGetContent(logic.getMpc(), this);

             return view;
        }

    @Override
    public void playlistCall(ArrayList<Mp3File> playlist, boolean change) {
        if (!isAdded()){
            MainActivity.panicMessage("PlayFragment is detached from Activity");
            return;
        }

        if (change){
            //final ArrayList<Mp3File> files1 = playlist;
            try {
                fileListAdapter.setCurrentSong(logic.mpcStatus.song.intValue());
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        fileListAdapter.notifyDataSetChanged();

                    }
                });
            } catch(Exception e){}
            }
    }

    @Override
    public void newMpdCall(Mp3File mp3File,int position, String command) {
        if (!isAdded()){
            MainActivity.panicMessage("PlayFragment is detached from Activity");
            return;
        }
        if (command.equals(getString(R.string.command_play)))
            logic.getMpc().play(position);
        if (command.equals(getString(R.string.playlist_removeall))){
            logic.getMpc().clearPlaylist();
        }
        if (command.equals(getString(R.string.playlist_removetop))){
            String message = "delete 0:" + (position + 1);
            Log.v("samba", message);
            logic.getMpc().sendSingleMessage(message);
        }
        if (command.equals(getString(R.string.playlist_removebottom))){
            logic.getMpc().sendSingleMessage("delete "+(position)+":"+(logic.getPlaylistFiles().size()+1));
        }
        if (command.equals(getString(R.string.playlist_removesong))){
            logic.getMpc().sendSingleMessage("delete "+(position));
        }
        if (command.equals(getString(R.string.playlist_movebottom))){
            logic.getMpc().sendSingleMessage("move "+(position)+" "+(logic.getPlaylistFiles().size()-1));
        }
        if (command.equals(getString(R.string.playlist_down))){
            logic.getMpc().sendSingleMessage("move "+(position)+" "+(position+1));
        }
        if (command.equals(getString(R.string.playlist_removeabum))){
            int top=logic.getPlaylistFiles().size()+1;
            int bottom=0;
            for (int i=0;i<logic.getPlaylistFiles().size();i++){
                if (mp3File.getAlbum().equals(logic.getPlaylistFiles().get(i).getAlbum())&&mp3File.getArtist().equals(logic.getPlaylistFiles().get(i).getArtist())){
                    if(top>i)top=i;
                    if (bottom<i)bottom=i;
                }
            }

            logic.getMpc().sendSingleMessage("delete "+(top)+":"+(bottom+1));
        }
    }

    @Override
    public void printCover(Bitmap result,  final ImageView image,String s) {

    }


}
