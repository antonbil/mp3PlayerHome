package examples.quickprogrammingtips.com.tablayout.model;

/**
 * Created by anton on 8-1-16.
 * A Sampler contains one or more songs from different Bans or Artists
 */
public class Sampler extends Album {
    public Sampler() {
    }
}
