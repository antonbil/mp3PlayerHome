package examples.quickprogrammingtips.com.tablayout.model;

/**
 * Created by anton on 23-1-16.
 */
public class Favorite {
    private String uri;
    private String description;

    public FavoriteRecord getRecord() {
        return record;
    }

    public void setRecord(FavoriteRecord record) {
        this.record = record;
    }

    private FavoriteRecord record;
    public Favorite(String uri, String description){
        this.uri=uri;
        this.description=description;

    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
